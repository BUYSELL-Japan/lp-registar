import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, PutCommand } from "@aws-sdk/lib-dynamodb";
import { toRomaji } from 'wanakana';

const ddbClient = new DynamoDBClient({ region: "ap-southeast-2" });
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);

// ★★★ 修正箇所: 新しいオリジンを定数として定義 ★★★
const ALLOWED_ORIGIN = "https://register.yuimaru-ship.box-pals.com"; 

export const handler = async (event) => {
    console.log("Received event:", JSON.stringify(event, null, 2));

    // ★★★ 修正箇所: CORSヘッダーを定義 ★★★
    const headers = {
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
        "Content-Type": "application/json"
    };

    let parsedBody;
    try {
        parsedBody = JSON.parse(event.body);
    } catch (error) {
        console.error("Failed to parse event body:", error, "Body content:", event.body);
        return {
            statusCode: 400,
            headers: headers, // ★★★ 修正箇所: 定義したヘッダーを使用 ★★★
            body: JSON.stringify({ message: "Invalid JSON format in request body." }),
        };
    }

    // OPTIONSリクエストの処理（CORSプリフライトリクエストに対応）
    if (event.httpMethod === "OPTIONS") {
        return { statusCode: 200, headers: headers };
    }

    try {
        const {
            store_id,
            storeNameKanji,
            storeNameFurigana,
            fullNameKanji,
            fullNameFurigana,
            zip,
            provinceKanji,
            provinceFurigana,
            cityKanji,
            cityFurigana,
            address1Kanji,
            address1Furigana,
            address2Kanji,
            address2Furigana,
            phone,
            contactEmail,
            cognito_sub, // 取得を追加
        } = parsedBody;

        // store_id と cognito_sub の両方が必須
        if (!store_id || !cognito_sub) {
            return {
                statusCode: 400,
                headers: headers, // ★★★ 修正箇所: 定義したヘッダーを使用 ★★★
                body: JSON.stringify({ message: "store_id and cognito_sub are required." }),
            };
        }

        // store_idの重複チェック (省略なし)
        // ...

        const romajiStoreName = toRomaji(storeNameFurigana);
        const romajiFullName = toRomaji(fullNameFurigana);
        const romajiProvince = toRomaji(provinceFurigana);
        const romajiCity = toRomaji(cityFurigana);
        const romajiAddress1 = toRomaji(address1Furigana);
        const romajiAddress2 = toRomaji(address2Furigana);

        const putCommand = new PutCommand({
            TableName: "Stores",
            Item: {
                store_id: store_id,
                cognito_sub: cognito_sub, // 保存処理に追加
                store_name: romajiStoreName,
                store_name_kanji: storeNameKanji,
                contact_email: contactEmail,
                created_at: new Date().toISOString(),
                from_address: {
                    address1: romajiAddress1,
                    address2: romajiAddress2 || "",
                    city: romajiCity,
                    country: "JP",
                    full_name: romajiFullName,
                    phone: phone,
                    province: romajiProvince,
                    zip: zip,
                },
            },
        });

        await ddbDocClient.send(putCommand);
        
        return {
            statusCode: 200,
            headers: headers, // ★★★ 修正箇所: 定義したヘッダーを使用 ★★★
            body: JSON.stringify({ message: "Store registered successfully!" }),
        };

    } catch (error) {
        console.error("Error registering store:", error);
        return {
            statusCode: 500,
            headers: headers, // ★★★ 修正箇所: 定義したヘッダーを使用 ★★★
            body: JSON.stringify({ message: "Failed to register store.", error: error.message }),
        };
    }
};